const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');


// Register route
exports.Register = async (req, res) => {
  const { email, password } = req.body;
  
  // Check if user already exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.status(400).json({ message: 'User already exists' });
  }
  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);
  
  // Create new user
  const user = new User({ email, password: hashedPassword });
  await user.save();
  
  res.status(201).json({ message: 'User registered successfully' });
};

// Login route
exports.Login = async (req, res) => {  
  const { email, password } = req.body;

  // Find user
  const user = await User.findOne({ email });
  if (!user) {
    return res.status(400).json({ message: 'Invalid credentials' });
  }

  // Check password
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ message: 'Invalid credentials' });
  }

  // Create JWT
  const token = jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET_TOKEN, { expiresIn: '1h' });
  
  res.json({ token });
};


