const Department = require('../models/Department');

// Create new department
exports.createDepartment = async (req, res) => {
  try {
    console.log(req.body);
  //   if (Department.departmentNumber === null || Department.departmentNumber === undefined) {
  //     throw new Error("Department number cannot be null or undefined");
  // }

  // const existingDepartment = await Department.findOne({ departmentNumber: Department.departmentNumber });
  // if (existingDepartment) {
  //     throw new Error("Department with this number already exists");
  // }

    const department = await Department.create(req.body);
    res.status(201).json({ department });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Get all departments
exports.getDepartments = async (req, res) => {
  try {
    const departments = await Department.find();
    res.status(200).json({ departments });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Update department
exports.updateDepartment = async (req, res) => {
  try {
    const department = await Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).json({ department });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Delete department
exports.deleteDepartment = async (req, res) => {
  try {
    await Department.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
