// controllers/dashboardController.js

const Employee = require('../models/Employee');
const Offboarding = require('../models/Offboarding');

exports.getDashboardMetrics = async (req, res) => {
    try {
        const employeeCount = await Employee.countDocuments();
        // const pendingQueriesCount = await Query.countDocuments({ status: 'pending' });
        const offboardingStats = await Offboarding.countDocuments();

        res.status(200).json({
            employeeCount,
            // pendingQueriesCount,
            offboardingStats,
        });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching dashboard metrics.', error });
    }
};
