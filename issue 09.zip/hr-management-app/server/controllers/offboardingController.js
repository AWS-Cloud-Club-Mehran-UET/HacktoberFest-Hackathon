// controllers/offboardingController.js

const Offboarding = require('../models/Offboarding');

// Submit offboarding request
exports.submitOffboarding = async (req, res) => {
    const { employeeId, resignationReason } = req.body;

    try {
        const offboarding = new Offboarding({ employeeId, resignationReason });
        await offboarding.save();
        
        // Logic to remove access to systems and facilities can be implemented here

        res.status(201).json({ message: 'Offboarding request submitted successfully.', offboarding });
    } catch (error) {
        res.status(500).json({ message: 'Error submitting offboarding request.', error });
    }
};

// Get offboarding details by employee ID
exports.getOffboardingByEmployeeId = async (req, res) => {
    try {
        const offboarding = await Offboarding.findOne({ employeeId: req.params.id });
        if (!offboarding) {
            return res.status(404).json({ message: 'No offboarding record found.' });
        }
        res.status(200).json(offboarding);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching offboarding record.', error });
    }
};
