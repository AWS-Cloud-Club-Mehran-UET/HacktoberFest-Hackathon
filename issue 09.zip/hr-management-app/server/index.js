const express = require('express');
const cors = require('cors');
const connectDB = require("./config/db");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
connectDB();

app.use(cors({
    origin: 'http://localhost:5173', 
    methods: ['GET', 'POST', 'PUT', 'DELETE'], 
    credentials: true, 
}));
// Routes
const employeeRoutes = require('./routes/employeeRoute');
const departmentRoutes = require('./routes/departmentRoutes');
const authRoutes = require('./routes/authRoutes');
const offboardingRoutes = require('./routes/offboardingRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

app.use('/api/employees', employeeRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/offboarding', offboardingRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.listen(PORT,()=>{
    console.log(`listening on ${PORT}`);
})
