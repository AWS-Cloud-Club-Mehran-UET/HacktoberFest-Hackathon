// routes/offboardingRoutes.js

const express = require('express');
const { submitOffboarding, getOffboardingByEmployeeId } = require('../controllers/offboardingController');

const router = express.Router();
router.post('/', submitOffboarding);
router.get('/:id', getOffboardingByEmployeeId);

module.exports = router;
