const mongoose = require("mongoose");

const employeeSchema = new mongoose.Schema({
  employeeNumber: { type: String,  unique: true, },
  name: { type: String,},
  designation: { type: String },
  department: { type: mongoose.Schema.Types.ObjectId, ref: "Department" },
  // department: { type: String, ref: "Department" },
  salary: { type: Number },
  startDate: { type: Date },
  personalEmail: { type: String },
  organizationEmail: { type: String },
  phoneNumber: { type: String },
  address: { type: String },
});

module.exports = mongoose.model("Employee", employeeSchema);
