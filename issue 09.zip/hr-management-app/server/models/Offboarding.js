// models/Offboarding.js

const mongoose = require('mongoose');

const offboardingSchema = new mongoose.Schema({
    employeeId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
        required: true,
    },
    resignationReason: {
        type: String,
        required: true,
    },
    resignationDate: {
        type: Date,
        default: Date.now,
    },
    clearanceForms: {
        type: Boolean,
        default: false,
    },
    exitInterviewCompleted: {
        type: Boolean,
        default: false,
    },
});

module.exports = mongoose.model('Offboarding', offboardingSchema);
