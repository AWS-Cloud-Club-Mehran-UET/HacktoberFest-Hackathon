const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
  departmentNumber: { type: String,unique: true},
  name: { type: String,  },
  chairman: { type: String,  },
  dean: { type: String,  },
});

module.exports = mongoose.model('Department', departmentSchema);
