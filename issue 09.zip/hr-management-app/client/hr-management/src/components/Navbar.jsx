import { Link } from 'react-router-dom';
import {useState,useEffect} from 'react'

const Navbar = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Auth state

  // Mock authentication check (you can replace this with your actual logic)
  useEffect(() => {
    const token = localStorage.getItem('token'); // Assuming you store a token on login
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);
  return (
    <nav>
      <h1>HR Management System</h1>
      <ul>
        {
          isAuthenticated ? <>
          <li><Link to="/">Dashboard</Link></li>
        <li><Link to="/employees">Employees</Link></li>
        <li><Link to="/departments">Departments</Link></li>
          </>:
        <li><Link to="/login">Login</Link></li>
        }
        
      </ul>
    </nav>
  );
};

export default Navbar;
