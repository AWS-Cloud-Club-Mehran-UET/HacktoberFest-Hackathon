import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HRDashboard from './pages/HRDashboard';
import EmployeeList from './pages/EmployeeList';
import AddEmployee from './pages/AddEmployee';
import EditEmployee from './pages/EditEmployee';
import DepartmentList from './pages/DepartmentList';
import AddDepartment from './pages/AddDepartment';
import EditDepartment from './pages/EditDepartment';
import Login from './pages/Login';
import Register from './pages/Register'; 
import Navbar from './components/Navbar';
import './App.css'
import {useState,useEffect} from 'react'
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false); 

  useEffect(() => {
    const token = localStorage.getItem('token'); 
    if (token) {
      setIsAuthenticated(true);
      // window.location.reload();
    }
    else {
      setIsAuthenticated(false);
    }
    
  }, []);
  return (
    <Router>
      <Navbar />
      <Routes>
        {
          isAuthenticated ?
          <>
           <Route path="/" element={<HRDashboard />} />
        <Route path="/employees" element={<EmployeeList />} />
        <Route path="/employees/add" element={<AddEmployee />} />
        <Route path="/employees/edit/:id" element={<EditEmployee />} />
        <Route path="/departments" element={<DepartmentList />} />
        <Route path="/departments/add" element={<AddDepartment />} />
        <Route path="/departments/edit/:id" element={<EditDepartment />} />
          </>:<>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} /> 
          </>
        }
       
       
      </Routes>
    </Router>
  )
}

export default App
