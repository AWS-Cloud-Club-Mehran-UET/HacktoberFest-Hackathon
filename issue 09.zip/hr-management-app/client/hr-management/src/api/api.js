import axios from 'axios';

const API_URL = 'http://localhost:8080/api'; // Replace with your backend URL

// Employee API
export const fetchEmployees = () => axios.get(`${API_URL}/employees`);
export const addEmployee = (employeeData) => axios.post(`${API_URL}/employees`, employeeData);
export const updateEmployee = (id, employeeData) => axios.put(`${API_URL}/employees/${id}`, employeeData);
export const deleteEmployee = (id) => axios.delete(`${API_URL}/employees/${id}`);

// Department API
export const fetchDepartments = () => axios.get(`${API_URL}/departments`);
export const addDepartment = (departmentData) => axios.post(`${API_URL}/departments`, departmentData);
export const updateDepartment = (id, departmentData) => axios.put(`${API_URL}/departments/${id}`, departmentData);
export const deleteDepartment = (id) => axios.delete(`${API_URL}/departments/${id}`);





export const login = async (data) => {
  return await axios.post(`${API_URL}/auth/login`, data);
};

export const register = async (data) => {
  return await axios.post(`${API_URL}/auth/register`, data);
};
