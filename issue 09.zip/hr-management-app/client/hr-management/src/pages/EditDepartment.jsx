import  { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchDepartments, updateDepartment } from '../api/api';

const EditDepartment = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const getDepartment = async () => {
      const response = await fetchDepartments();
      const department = response.data.departments.find(dep => dep._id === id);
      setFormData(department);
    };

    getDepartment();
  }, [id]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateDepartment(id, formData);
    navigate('/departments');
  };

  return (
    <div>
      <h2>Edit Department</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="number" value={formData.number} onChange={handleChange} required />
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        <input type="text" name="chairman" value={formData.chairman} onChange={handleChange} required />
        <input type="text" name="dean" value={formData.dean} onChange={handleChange} required />
        <button type="submit">Update Department</button>
      </form>
    </div>
  );
};

export default EditDepartment;
