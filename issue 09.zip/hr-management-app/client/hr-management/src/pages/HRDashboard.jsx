import { useEffect, useState } from "react";
import axios from "axios";

const HRDashboard = () => {
  const [metrics, setMetrics] = useState({
    employeeCount: 0,
    pendingQueriesCount: 0,
    onboardingStats: 0,
  });

  useEffect(() => {
    const fetchMetrics = async () => {
      const res = await axios.get("http://localhost:8080/api/dashboard");
      setMetrics(res.data);
    };

    fetchMetrics();
  }, []);

  return (
    <div className="dashboard">
      <h1>HR Dashboard</h1>
      <div className="metrics">
        <div className="metric">
          <h2>Total Employees</h2>
          <p>{metrics.employeeCount || 0 }</p>
        </div>
        
        <div className="metric">
          <h2>Onboarding Requests</h2>
          <p>{metrics.onboardingStats || 0}</p>
        </div>
      </div>
    </div>
  );
};

export default HRDashboard;
