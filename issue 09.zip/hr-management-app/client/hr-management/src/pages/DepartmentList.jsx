import { useState, useEffect } from 'react';
import { fetchDepartments, deleteDepartment } from '../api/api';
import { Link } from 'react-router-dom';

const DepartmentList = () => {
  const [departments, setDepartments] = useState([]);
  const [searchText, setSearchText] = useState(''); // State for search input

  useEffect(() => {
    const getDepartments = async () => {
      const response = await fetchDepartments();
      setDepartments(response.data.departments);
    };
    getDepartments();
  }, []);

  const handleDelete = async (id) => {
    await deleteDepartment(id);
    setDepartments(departments.filter(dep => dep._id !== id));
  };

  // Filter departments based on searchText
  const filteredDepartments = departments.filter(department => 
    department.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div>
      <h2>Department List</h2>
      <Link to="/departments/add">Add Department</Link>
      
      {/* Search input */}
      <input 
        type="text" 
        placeholder="Search by department name..." 
        value={searchText} 
        onChange={(e) => setSearchText(e.target.value)} 
      />
      
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Chairman</th>
            <th>Dean</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredDepartments.map(department => (
            <tr key={department._id}>
              <td>{department.name}</td>
              <td>{department.chairman}</td>
              <td>{department.dean}</td>
              <td>
                <Link to={`/departments/edit/${department._id}`}>Edit</Link>
                <button onClick={() => handleDelete(department._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DepartmentList;
