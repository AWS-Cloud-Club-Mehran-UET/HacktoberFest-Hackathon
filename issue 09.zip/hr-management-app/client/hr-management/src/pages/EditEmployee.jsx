import{ useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchEmployees, updateEmployee, fetchDepartments } from '../api/api';

const EditEmployee = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({});
  const [departments, setDepartments] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const getEmployee = async () => {
      const response = await fetchEmployees();
      const employee = response.data.employees.find(emp => emp._id === id);
      setFormData(employee);
    };

    const getDepartments = async () => {
      const response = await fetchDepartments();
      setDepartments(response.data.departments);
    };

    getEmployee();
    getDepartments();
  }, [id]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateEmployee(id, formData);
    navigate('/employees');
  };

  return (
    <div>
      <h2>Edit Employee</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="employeeNumber" value={formData.employeeNumber} onChange={handleChange} required />
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        <input type="text" name="designation" value={formData.designation} onChange={handleChange} required />
        <select name="department" value={formData.department} onChange={handleChange} required>
          <option value="">Select Department</option>
          {departments.map(department => (
            <option key={department._id} value={department._id}>{department.name}</option>
          ))}
        </select>
        <input type="number" name="salary" value={formData.salary} onChange={handleChange} required />
        <input type="date" name="startDate" value={formData.startDate} onChange={handleChange} required />
        <input type="email" name="personalEmail" value={formData.personalEmail} onChange={handleChange} required />
        <input type="email" name="organizationEmail" value={formData.organizationEmail} onChange={handleChange} required />
        <input type="text" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} required />
        <input type="text" name="address" value={formData.address} onChange={handleChange} required />
        <button type="submit">Update Employee</button>
      </form>
    </div>
  );
};

export default EditEmployee;
