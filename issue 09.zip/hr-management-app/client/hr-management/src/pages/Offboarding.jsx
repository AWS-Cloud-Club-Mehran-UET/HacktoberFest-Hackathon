// src/pages/Offboarding.jsx

import  { useEffect, useState } from 'react';
import axios from 'axios';

const Offboarding = ({ employeeId }) => {
    const [employee, setEmployee] = useState(null);
    const [resignationReason, setResignationReason] = useState('');

    useEffect(() => {
        const fetchEmployeeData = async () => {
            const res = await axios.get(`http://localhost:8080/api/employees/${employeeId}`);
            setEmployee(res.data);
        };

        fetchEmployeeData();
    }, [employeeId]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:8080/api/offboarding', {
            employeeId: employee._id,
            resignationReason,
        });
        // Handle success and show a message or redirect
    };

    return (
        <form onSubmit={handleSubmit}>
            {employee && (
                <>
                    <h2>Offboarding Form for {employee.name}</h2>
                    <label>
                        Reason for Resignation:
                        <input
                            type="text"
                            value={resignationReason}
                            onChange={(e) => setResignationReason(e.target.value)}
                            required
                        />
                    </label>
                    <button type="submit">Submit Offboarding</button>
                </>
            )}
        </form>
    );
};

export default Offboarding;
