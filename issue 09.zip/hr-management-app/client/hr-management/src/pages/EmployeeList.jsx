import { useState, useEffect } from 'react';
import { fetchEmployees, deleteEmployee } from '../api/api';
import { Link } from 'react-router-dom';

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const getEmployees = async () => {
      const response = await fetchEmployees();
      setEmployees(response.data.employees);
    };
    getEmployees();
  }, []);

  const handleDelete = async (id) => {
    await deleteEmployee(id);
    setEmployees(employees.filter(emp => emp._id !== id));
  };

  // Filter employees based on searchText
  const filteredEmployees = employees.filter(employee => 
    employee.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div>
      <h2>Employee List</h2>
      <Link to="/employees/add">Add Employee</Link>
      <input 
        type="text" 
        placeholder='Search by name of Employee...' 
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)} 
      />
      <table>
        <thead>
          <tr>
            <th>Employee Number</th>
            <th>Name</th>
            <th>Designation</th>
            <th>Department</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map(employee => (
            <tr key={employee._id}>
              <td>{employee.employeeNumber}</td>
              <td>{employee.name}</td>
              <td>{employee.designation}</td>
              <td>{employee.department?.name}</td>
              <td>
                <Link to={`/employees/edit/${employee._id}`}>Edit</Link>
                <button onClick={() => handleDelete(employee._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
