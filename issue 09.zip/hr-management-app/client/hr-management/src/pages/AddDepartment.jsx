import  { useState } from 'react';
import { addDepartment } from '../api/api';
import { useNavigate } from 'react-router-dom';

const AddDepartment = () => {
  const [formData, setFormData] = useState({
    // number: '',
    name: '',
    chairman: '',
    dean: ''
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addDepartment(formData);
    navigate('/departments');
  };

  return (
    <div>
      <h2>Add Department</h2>
      <form onSubmit={handleSubmit}>
        {/* <input type="text" name="number" placeholder="Department Number" onChange={handleChange} required /> */}
        <input type="text" name="name" placeholder="Department Name" onChange={handleChange} required />
        <input type="text" name="chairman" placeholder="Chairman" onChange={handleChange} required />
        <input type="text" name="dean" placeholder="Dean" onChange={handleChange} required />
        <button type="submit">Add Department</button>
      </form>
    </div>
  );
};

export default AddDepartment;
