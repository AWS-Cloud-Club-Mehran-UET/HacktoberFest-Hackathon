import { useState, useEffect } from 'react';
import { addEmployee, fetchDepartments } from '../api/api';
import { useNavigate } from 'react-router-dom';

const AddEmployee = () => {
  const [formData, setFormData] = useState({
    employeeNumber: '',
    name: '',
    designation: '',
    department: '',
    salary: '',
    startDate: '',
    personalEmail: '',
    organizationEmail: '',
    phoneNumber: '',
    address: ''
  });
  const [departments, setDepartments] = useState([{
     id:'1',
     name: 'IT'
  }]);
  const navigate = useNavigate();

  useEffect(() => {
    const getDepartments = async () => {
      const response = await fetchDepartments();
      setDepartments(response.data.departments);
    };
    getDepartments();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addEmployee(formData);
    navigate('/employees');
  };

  return (
    <div>
      <h2>Add Employee</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="employeeNumber" placeholder="Employee Number" onChange={handleChange}  />
        <input type="text" name="name" placeholder="Name" onChange={handleChange}  />
        <input type="text" name="designation" placeholder="Designation" onChange={handleChange}  />
        <select name="department" onChange={handleChange} >
          <option value="">Select Department</option>
          {departments.map(department => (
            <option key={department._id} value={department._id}>{department.name}</option>
          ))}
        </select>
        <input type="number" name="salary" placeholder="Salary" onChange={handleChange}  />
        <input type="date" name="startDate" onChange={handleChange}  />
        <input type="email" name="personalEmail" placeholder="Personal Email" onChange={handleChange}  />
        <input type="email" name="organizationEmail" placeholder="Organization Email" onChange={handleChange}  />
        <input type="text" name="phoneNumber" placeholder="Phone Number" onChange={handleChange}  />
        <input type="text" name="address" placeholder="Address" onChange={handleChange}  />
        <button type="submit">Add Employee</button>
      </form>
    </div>
  );
};

export default AddEmployee;
