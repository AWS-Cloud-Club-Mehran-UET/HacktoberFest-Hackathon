HR Management System - Issue Resolution
Overview:
This HR management system handles employee onboarding/offboarding, queries, and HR admin tasks. The project uses React (frontend), Node.js/Express (backend), and MongoDB (database).
Key Issues & Solutions:
1. Offboarding Process:
  Created a form for HR admins/employees to automate the offboarding process, with auto-population of employee data, and automation of resignation submissions, clearance forms, and exit tasks.
Challenges: Handling auto-population and automation. 
2.Dashboard Enhancements:
Solution: Displayed key HR metrics for admins and onboarding/offboarding tasks for employees.
3. CORS Issue:
Solution:Configured CORS middleware in the backend to resolve blocked API requests.
Challenges included data fetching, form validation, and proper role management.