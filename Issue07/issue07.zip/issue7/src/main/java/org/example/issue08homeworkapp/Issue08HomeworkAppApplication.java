package org.example.issue08homeworkapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Issue08HomeworkAppApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(Issue08HomeworkAppApplication.class, args);
    }

}
