package org.example.issue08homeworkapp.Service;

import org.example.issue08homeworkapp.Entity.Task;
import org.springframework.stereotype.Component;

@Component
public class PendingTaskQueue {

    private static class Node{
        Task task;
        Node previous;
        Node next;
        Node(Task task){
            this.task=null;
            previous=this;
            next=this;
        }
        Node(Task task,Node previous,Node next){
            this.task=task;
            this.previous=previous;
            this.next=next;
        }
    }
    Node head=new Node(null);
    int size;

    public void enqueue(Task task) {
        size++;
        head.previous.next =new Node(task, head.previous, head);
        head.previous = head.previous.next;
    }


    public Task first() {
        if(size==0) throw new IllegalArgumentException("Queue is empty");
        return head.next.task;
    }

    public Task dequeue() {
        Task temp=head.next.task;
        head.next=head.next.next;
        head.next.previous=head;
        size--;
        return temp;
    }

    public boolean isEmpty() {
        return false;
    }

    public int size() {
        return size;
    }
}
