package org.example.issue08homeworkapp.Service;

import org.example.issue08homeworkapp.Entity.Task;
import org.springframework.stereotype.Component;

@Component
public class CompletedTaskStack{
        public static class Node{
            Task task;
            Node next;
            Node(Task tak,Node next){
                task=tak;
                this.next=next;
            }
        }
        private Node top;
        private int size;


        public Task peek() {
            if(size==0) throw new IllegalArgumentException("Stack is empty");
            return top.task;
        }

        public void push(Task task) {
            ++size;
            top=new Node(task,top);
        }
        public Task pop() {
            if(size==0) throw new IllegalArgumentException("Stack is empty");
            Task oldTop=top.task;
            top=top.next;
            --size;
            return oldTop;
        }
        public int size() {
            return size;
        }
        public String toString(){
            Node temp= top;
            String list="";
            while (temp!=null){
                list += temp.task.toString()+"\n";
                temp=temp.next;
            }
            return list;
        }
}
