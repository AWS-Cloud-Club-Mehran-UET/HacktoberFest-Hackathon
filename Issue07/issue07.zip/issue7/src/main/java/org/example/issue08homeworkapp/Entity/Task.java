package org.example.issue08homeworkapp.Entity;

import java.util.Objects;

public class Task
{
    public String Name;
    public Boolean IsCompleted;

    public Task(String name, Boolean isCompleted)
    {
        Name = name;
        IsCompleted = isCompleted;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Boolean getCompleted() {
        return IsCompleted;
    }


    public void setCompleted(Boolean completed) {
        IsCompleted = completed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return Objects.equals(Name, task.Name) && Objects.equals(IsCompleted, task.IsCompleted);
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
