package org.example.issue08homeworkapp.MainControllers;


import org.example.issue08homeworkapp.Service.CompletedTaskStack;
import org.example.issue08homeworkapp.Service.PendingTaskQueue;

import org.example.issue08homeworkapp.Entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.swing.text.html.parser.Entity;
import java.util.ArrayList;
import java.util.Deque;


@RestController
@RequestMapping("/HomeWork")
public class Controller
{
    @Autowired
    PendingTaskQueue PTQ;
    @Autowired
    CompletedTaskStack CTS;

    @PostMapping
    public void createTask(@RequestBody Task task)
    {
        PTQ.enqueue(task);
    }

    @GetMapping
    public Task getTask() {
        if (PTQ.isEmpty()) {
            return null;
        }
        return PTQ.first();
    }
    @DeleteMapping()
    public Task Delete()
    {
        Task t = PTQ.dequeue();
        CTS.push(t);
        return t;
    }
}
