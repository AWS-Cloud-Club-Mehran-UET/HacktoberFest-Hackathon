package org.example.issue08homeworkapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Issue08HomeworkAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
