const Userapi= 'http://localhost:8080/HomeWork'
class Userfetch{
    
    getuser(){
        return fetch(Userapi).then((res => res.json))
    }

}
export default Userfetch