
function Cards(props){
    return(
        <div className="card">
            
            <h1 className="card_title"> {props.des} </h1>
        </div>
    )
}

export default Cards