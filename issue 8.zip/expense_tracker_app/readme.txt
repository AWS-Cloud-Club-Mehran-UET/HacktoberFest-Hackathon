Features :
I used firebase for authentication and firestore for storing incomes and expenses and data, 
I used getx as state management and used mvc pattern for writing code, I used ScreenUtilInit package for responsiveness 
I also used 
shared preferrences for storing user session related data .

