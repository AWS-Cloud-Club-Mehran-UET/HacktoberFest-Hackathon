import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SignUpController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  static FirebaseFirestore firestore = FirebaseFirestore.instance;

  final auth = FirebaseAuth.instance;
  final passController = TextEditingController();
  RxBool isLoading = false.obs;
  signUp(BuildContext context) async {
    try {
      isLoading.value = true;
      UserCredential user = await auth.createUserWithEmailAndPassword(
        email: emailController.text,
        password: passController.text,
      );
      await firestore.collection("users").doc(user.user!.uid).set({
        "email": emailController.text,
        "pass": passController.text,
        "uid": user.user!.uid
      });
      var pref = await SharedPreferences.getInstance();
      pref.setString("uid", user.user!.uid);
      pref.setString("email", emailController.text);
      Fluttertoast.showToast(msg: "Sign up successful", fontSize: 14.sp);

      isLoading.value = false;

      Get.back();
    } on FirebaseAuthException {
      isLoading.value = false;

      Fluttertoast.showToast(msg: "Something went wrong", fontSize: 14.sp);
    }
  }
}
