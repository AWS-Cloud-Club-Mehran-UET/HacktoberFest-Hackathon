import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddIncomeController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final amountController = TextEditingController();
  static FirebaseFirestore firestore = FirebaseFirestore.instance;

  final dateController = TextEditingController();

  RxBool flag = false.obs;
  String? selectedCategory;
  DateTime? selectedDate;
  Future<void> selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      selectedDate = picked;
      dateController.text =
          "${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}";
    }
  }

  final List<String> categories = ["Job", "Business"];
  addIncome() async {
    var pref = await SharedPreferences.getInstance();
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final uid = pref.getString("uid");
    await firestore
        .collection("users")
        .doc(uid)
        .collection("incomes")
        .doc(id)
        .set({
      "amount": amountController.text,
      "date": dateController.text,
      "category": selectedCategory,
    });
    Fluttertoast.showToast(msg: "Success");
  }
}
