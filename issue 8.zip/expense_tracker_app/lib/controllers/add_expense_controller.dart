import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddExpenseController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final amountController = TextEditingController();
  final dateController = TextEditingController();
  static FirebaseFirestore firestore = FirebaseFirestore.instance;

  RxBool flag = false.obs;
  String? selectedCategory;
  DateTime? selectedDate;
  Future<void> selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      selectedDate = picked;
      dateController.text =
          "${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}";
    }
  }

  final List<String> categories = ["Food", "Rent", "Entertainment"];
  addExpense() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String uid = pref.getString("uid")!;
    String id = DateTime.now().millisecondsSinceEpoch.toString();
    await firestore
        .collection("users")
        .doc(uid)
        .collection("expenses")
        .doc(id)
        .set({
      "amount": amountController.text,
      "category": selectedCategory,
      "date": dateController.text
    });
    Fluttertoast.showToast(msg: "Success");
  }
}
