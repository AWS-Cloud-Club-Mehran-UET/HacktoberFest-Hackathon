import 'package:expense_tracker_app/screens/add_expense_screen.dart';
import 'package:expense_tracker_app/screens/dashboard_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passController = TextEditingController();
  RxBool isLoading = false.obs;
  final auth = FirebaseAuth.instance;
  signIn() async {
    try {
      isLoading.value = true;
      UserCredential user = await auth.signInWithEmailAndPassword(
        email: emailController.text,
        password: passController.text,
      );
      isLoading.value = false;

      Fluttertoast.showToast(msg: "Login success", fontSize: 14.sp);
      var pref = await SharedPreferences.getInstance();
      pref.setString("uid", user.user!.uid);
      pref.setString("email", emailController.text);

      Get.off(DashboardScreen());
    } catch (e) {
      isLoading.value = false;
      Fluttertoast.showToast(msg: "Something went wrong", fontSize: 14.sp);
    }
  }
}
