import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:expense_tracker_app/screens/add_expense_screen.dart';
import 'package:expense_tracker_app/screens/add_income_screen.dart';
import 'package:expense_tracker_app/screens/login_screen.dart';
import 'package:expense_tracker_app/screens/show_expenses_screen.dart';
import 'package:expense_tracker_app/screens/show_income_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DashboardScreen extends StatefulWidget {
  DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool flag = false;
  int lifeExpenses = 0;
  int lifeIncomes = 0;
  fetchLifeTimeData() async {
    final prefs = await SharedPreferences.getInstance();
    var uid = prefs.getString("uid")!;
    var expDocs;
    var expenses = await FirebaseFirestore.instance
        .collection("users")
        .doc(uid)
        .collection("expenses")
        .get()
        .then((val) {
      expDocs = val.docs;
    });
    for (int i = 0; i < expDocs.length; i++) {
      lifeExpenses += int.parse(expDocs[i]['amount']);
    }
    var incDocs;
    var incomes = await FirebaseFirestore.instance
        .collection("users")
        .doc(uid)
        .collection("incomes")
        .get()
        .then((val) {
      incDocs = val.docs;
    });
    for (int i = 0; i < incDocs.length; i++) {
      lifeIncomes += int.parse(incDocs[i]['amount']);
    }
    setState(() {});
  }

  @override
  void initState() {
    fetchLifeTimeData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          GestureDetector(
              onTap: () {
                if (!flag) {
                  flag = !flag;
                  Get.changeTheme(ThemeData.dark());
                } else {
                  flag = !flag;

                  Get.changeTheme(ThemeData.light());
                }
              },
              child: const Icon(Icons.dark_mode)),
          const SizedBox(
            width: 20,
          ),
          GestureDetector(
              onTap: () async {
                FirebaseAuth.instance.signOut();
                var prefs = await SharedPreferences.getInstance();
                prefs.remove("uid");
                prefs.remove("email");
                Get.offAll(const LoginScreen());
              },
              child: const Icon(
                Icons.logout,
                color: Colors.red,
              ))
        ],
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "Dashboard Screen",
          style: TextStyle(fontSize: 17.sp),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: 10,
          ),
          Text("LifeTime incomes : $lifeIncomes"),
          const SizedBox(
            height: 10,
          ),
          Text("LifeTime expanses : $lifeExpenses"),
          const SizedBox(
            height: 10,
          ),
          lifeExpenses > lifeIncomes
              ? const Text("current balance :0")
              : Text("current balance :${lifeIncomes - lifeExpenses}"),
          Center(
              child: ElevatedButton(
                  onPressed: () {
                    Get.to(const AddExpenseScreen());
                  },
                  child: const Text("Add Expense"))),
          ElevatedButton(
              onPressed: () {
                Get.to(const AddIncomeScreen());
              },
              child: const Text("Add Income")),
          ElevatedButton(
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                var uid = prefs.getString("uid")!;
                Get.to(ShowExpenses(
                  uid: uid,
                ));
              },
              child: const Text("Show Expenses")),
          ElevatedButton(
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                var uid = prefs.getString("uid")!;
                Get.to(ShowIncomes(
                  uid: uid,
                ));
              },
              child: const Text("Show Incomes"))
        ],
      ),
    );
  }
}
