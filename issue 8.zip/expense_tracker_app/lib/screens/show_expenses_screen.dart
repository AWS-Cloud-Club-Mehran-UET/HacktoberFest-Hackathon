import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ShowExpenses extends StatefulWidget {
  final String uid;
  const ShowExpenses({super.key, required this.uid});

  @override
  State<ShowExpenses> createState() => _ShowExpensesState();
}

class _ShowExpensesState extends State<ShowExpenses> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Expenses"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("users")
              .doc(widget.uid)
              .collection("expenses")
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.waiting) {
              var expenses = snapshot.data!.docs;
              print(expenses.length);
              return ListView.builder(
                  itemCount: expenses.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        trailing: GestureDetector(
                            onTap: () {
                              expenses[index].reference.delete();
                            },
                            child: const Icon(
                              Icons.delete,
                              color: Colors.red,
                            )),
                        title: Text("Amount :" + expenses[index]['amount']),
                        subtitle:
                            Text("Category :" + expenses[index]['category']),
                      ),
                    );
                  });
            }
            return const Center(
              child: SizedBox(
                  height: 20, width: 20, child: CircularProgressIndicator()),
            );
          }),
    );
  }
}
