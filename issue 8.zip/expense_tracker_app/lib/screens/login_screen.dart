import 'package:expense_tracker_app/controllers/login_screen_controller.dart';
import 'package:expense_tracker_app/screens/sign_up_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(LoginController());
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "Login Screen",
          style: TextStyle(fontSize: 17.sp),
        ),
      ),
      body: Form(
        key: c.formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Email can't be empty";
                    } else if (!GetUtils.isEmail(val)) {
                      return "Enter valid email";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintText: "Email",
                      hintStyle: TextStyle(fontSize: 14.sp),
                      border: const OutlineInputBorder()),
                  controller: c.emailController,
                ),
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Password can't be empty";
                    } else if (val.length < 8) {
                      return "Password should be 8 characters long";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintStyle: TextStyle(fontSize: 14.sp),
                      hintText: "Password",
                      border: const OutlineInputBorder()),
                  controller: c.passController,
                ),
                SizedBox(
                  height: 50.h,
                ),
                Obx(() => ElevatedButton(
                    onPressed: () {
                      if (c.formKey.currentState!.validate()) {}
                      c.signIn();
                    },
                    child: c.isLoading.value
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.black,
                            ),
                          )
                        : Text(
                            "Login",
                            style: TextStyle(fontSize: 14.sp),
                          ))),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                        onTap: () {
                          Get.to(const SignUpScreen());
                        },
                        child: Text("Dont have an account",
                            style: TextStyle(fontSize: 14.sp)))
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
