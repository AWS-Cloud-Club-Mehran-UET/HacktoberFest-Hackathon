import 'package:expense_tracker_app/controllers/sign_up_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(SignUpController());
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "Sign Up Screen",
          style: TextStyle(fontSize: 17.sp),
        ),
      ),
      body: Form(
        key: c.formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Email can't be empty";
                    } else if (!GetUtils.isEmail(val)) {
                      return "Enter valid email";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintStyle: TextStyle(fontSize: 14.sp),
                      hintText: "Email",
                      border: const OutlineInputBorder()),
                  controller: c.emailController,
                ),
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Password can't be empty";
                    } else if (val.length < 8) {
                      return "Password should be 8 characters long";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintText: "Password",
                      hintStyle: TextStyle(fontSize: 14.sp),
                      border: const OutlineInputBorder()),
                  controller: c.passController,
                ),
                SizedBox(
                  height: 50.h,
                ),
                Obx(() => ElevatedButton(
                    onPressed: () {
                      if (c.formKey.currentState!.validate()) {
                        c.signUp(context);
                      }
                    },
                    child: c.isLoading.value
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.black,
                            ),
                          )
                        : Text(
                            "Sign Up",
                            style: TextStyle(fontSize: 14.sp),
                          ))),
                SizedBox(
                  height: 10.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
