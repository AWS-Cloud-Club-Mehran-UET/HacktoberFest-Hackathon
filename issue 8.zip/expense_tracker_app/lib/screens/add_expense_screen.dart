import 'package:expense_tracker_app/controllers/add_expense_controller.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AddExpenseScreen extends StatelessWidget {
  const AddExpenseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(AddExpenseController());
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "Add Expense Screen",
          style: TextStyle(fontSize: 17.sp),
        ),
      ),
      body: Form(
        key: c.formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  keyboardType: TextInputType.number,
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Amount can't be empty";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                      hintText: "Amount",
                      hintStyle: TextStyle(fontSize: 14.sp),
                      border: const OutlineInputBorder()),
                  controller: c.amountController,
                ),
                SizedBox(
                  height: 20.h,
                ),
                Obx(
                  () => c.flag.value
                      ? DropdownButton<String>(
                          hint: Text(
                            "Select a category",
                            style: TextStyle(fontSize: 14.sp),
                          ),
                          value: c.selectedCategory,
                          items: c.categories.map((String category) {
                            return DropdownMenuItem<String>(
                              value: category,
                              child: Text(category),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            c.selectedCategory = newValue;
                            c.flag.value = !c.flag.value;
                          },
                        )
                      : DropdownButton<String>(
                          hint: Text(
                            "Select a category",
                            style: TextStyle(fontSize: 14.sp),
                          ),
                          value: c.selectedCategory,
                          items: c.categories.map((String category) {
                            return DropdownMenuItem<String>(
                              value: category,
                              child: Text(category),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            c.selectedCategory = newValue;
                            c.flag.value = !c.flag.value;
                          },
                        ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  onTap: () {
                    c.selectDate(context);
                  },
                  readOnly: true,
                  controller: c.dateController,
                  decoration: InputDecoration(
                      hintText: "Date",
                      hintStyle: TextStyle(fontSize: 14.sp),
                      border: const OutlineInputBorder()),
                ),
                SizedBox(
                  height: 50.h,
                ),
                ElevatedButton(
                    onPressed: () {
                      if (c.formKey.currentState!.validate()) {
                        if (c.selectedCategory == null) {
                          Fluttertoast.showToast(msg: "category cant be empty");
                        } else {
                          c.addExpense();
                        }
                      }
                    },
                    child: Text(
                      "Add",
                      style: TextStyle(fontSize: 14.sp),
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
