import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ShowIncomes extends StatefulWidget {
  final String uid;
  const ShowIncomes({super.key, required this.uid});

  @override
  State<ShowIncomes> createState() => _ShowIncomesState();
}

class _ShowIncomesState extends State<ShowIncomes> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Incomes"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("users")
              .doc(widget.uid)
              .collection("incomes")
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.waiting) {
              var incomes = snapshot.data!.docs;
              print(incomes.length);
              return ListView.builder(
                  itemCount: incomes.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        trailing: GestureDetector(
                            onTap: () {
                              incomes[index].reference.delete();
                            },
                            child: const Icon(
                              Icons.delete,
                              color: Colors.red,
                            )),
                        title: Text("Amount :" + incomes[index]['amount']),
                        subtitle:
                            Text("Category :" + incomes[index]['category']),
                      ),
                    );
                  });
            }
            return const Center(
              child: SizedBox(
                  height: 20, width: 20, child: CircularProgressIndicator()),
            );
          }),
    );
  }
}
